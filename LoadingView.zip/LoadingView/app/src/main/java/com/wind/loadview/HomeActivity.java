package com.wind.loadview;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

/**
 * <pre>
 *     作者   : lime
 *     时间   : 2020/01/18
 *     描述   :
 *     版本   : 1.0
 * </pre>
 */

public class HomeActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

    }
}
